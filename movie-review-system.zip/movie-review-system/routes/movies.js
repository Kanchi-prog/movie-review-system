const express = require('express');
const mongoose = require('mongoose');
const Movie = require('../models/Movie');

const router = express.Router();

// Reject malformed ids early
router.param('id', (req, res, next, id) => {
  if (!mongoose.isValidObjectId(id)) return res.status(400).json({ error: 'Invalid movie id' });
  next();
});

const escapeRegex = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

// GET /api/movies?search=&genre=&sort=
router.get('/', async (req, res, next) => {
  try {
    const { search, genre, sort } = req.query;
    const filter = {};
    if (genre && genre !== 'all') filter.genre = genre;
    if (search) {
      const rx = new RegExp(escapeRegex(search), 'i');
      filter.$or = [{ title: rx }, { director: rx }];
    }

    const movies = await Movie.find(filter).sort({ createdAt: -1 });

    // avgRating is a virtual, so sort in JS
    switch (sort) {
      case 'rating':  movies.sort((a, b) => b.avgRating - a.avgRating); break;
      case 'reviews': movies.sort((a, b) => b.reviewCount - a.reviewCount); break;
      case 'year':    movies.sort((a, b) => b.year - a.year); break;
      case 'title':   movies.sort((a, b) => a.title.localeCompare(b.title)); break;
    }
    res.json(movies);
  } catch (err) { next(err); }
});

// GET /api/movies/stats  -> dashboard numbers
router.get('/stats', async (req, res, next) => {
  try {
    const movies = await Movie.find();
    const allReviews = movies.flatMap((m) => m.reviews);
    const avg = allReviews.length
      ? Math.round((allReviews.reduce((t, r) => t + r.rating, 0) / allReviews.length) * 10) / 10
      : 0;
    res.json({ movies: movies.length, reviews: allReviews.length, averageRating: avg });
  } catch (err) { next(err); }
});

// GET /api/movies/:id
router.get('/:id', async (req, res, next) => {
  try {
    const movie = await Movie.findById(req.params.id);
    if (!movie) return res.status(404).json({ error: 'Movie not found' });
    res.json(movie);
  } catch (err) { next(err); }
});

// POST /api/movies
router.post('/', async (req, res, next) => {
  try {
    const { title, director, genre, year, duration, description } = req.body;
    const movie = await Movie.create({ title, director, genre, year, duration, description });
    res.status(201).json(movie);
  } catch (err) { next(err); }
});

// PUT /api/movies/:id
router.put('/:id', async (req, res, next) => {
  try {
    const { title, director, genre, year, duration, description } = req.body;
    const movie = await Movie.findByIdAndUpdate(
      req.params.id,
      { title, director, genre, year, duration, description },
      { new: true, runValidators: true }
    );
    if (!movie) return res.status(404).json({ error: 'Movie not found' });
    res.json(movie);
  } catch (err) { next(err); }
});

// DELETE /api/movies/:id
router.delete('/:id', async (req, res, next) => {
  try {
    const movie = await Movie.findByIdAndDelete(req.params.id);
    if (!movie) return res.status(404).json({ error: 'Movie not found' });
    res.json({ message: 'Movie deleted' });
  } catch (err) { next(err); }
});

// POST /api/movies/:id/reviews
router.post('/:id/reviews', async (req, res, next) => {
  try {
    const movie = await Movie.findById(req.params.id);
    if (!movie) return res.status(404).json({ error: 'Movie not found' });
    const { reviewer, rating, comment } = req.body;
    movie.reviews.unshift({ reviewer, rating, comment });
    await movie.save();
    res.status(201).json(movie);
  } catch (err) { next(err); }
});

// DELETE /api/movies/:id/reviews/:reviewId
router.delete('/:id/reviews/:reviewId', async (req, res, next) => {
  try {
    const movie = await Movie.findById(req.params.id);
    if (!movie) return res.status(404).json({ error: 'Movie not found' });
    const review = movie.reviews.id(req.params.reviewId);
    if (!review) return res.status(404).json({ error: 'Review not found' });
    review.deleteOne();
    await movie.save();
    res.json(movie);
  } catch (err) { next(err); }
});

module.exports = router;
