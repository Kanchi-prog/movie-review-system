/* Reelnotes – front-end logic (vanilla JS, talks to the Express/MongoDB API) */
const API = '/api/movies';

const $ = (id) => document.getElementById(id);
const grid = $('movieGrid');
const emptyBox = $('empty');
const movieDialog = $('movieDialog');
const detailDialog = $('detailDialog');

let openMovieId = null;      // movie currently shown in the detail dialog
let searchTimer = null;

/* ---------- helpers ---------- */
function esc(str = '') {
  const d = document.createElement('div');
  d.textContent = String(str);
  return d.innerHTML;
}
function hueFor(text) {   // stable colour per genre
  let h = 0;
  for (const c of text) h = (h * 31 + c.charCodeAt(0)) % 360;
  return h;
}
function stars(value) {
  const full = Math.round(value);
  return `<span class="stars" aria-label="${value} out of 5">` +
    [1, 2, 3, 4, 5].map((i) => `<span class="${i <= full ? 'on' : 'off'}">★</span>`).join('') + '</span>';
}
function toast(msg, isError = false) {
  const t = $('toast');
  t.textContent = msg;
  t.className = 'toast show' + (isError ? ' error' : '');
  clearTimeout(t._t);
  t._t = setTimeout(() => (t.className = 'toast'), 2600);
}
async function api(url, options = {}) {
  const res = await fetch(url, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
    body: options.body ? JSON.stringify(options.body) : undefined
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}
const fmtDate = (d) => new Date(d).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' });

/* ---------- load + render list ---------- */
async function loadStats() {
  try {
    const s = await api(`${API}/stats`);
    $('statMovies').textContent = s.movies;
    $('statReviews').textContent = s.reviews;
    $('statAvg').textContent = s.averageRating.toFixed(1);
  } catch { /* stats are optional */ }
}

async function loadMovies() {
  const params = new URLSearchParams({
    search: $('search').value.trim(),
    genre: $('genreFilter').value,
    sort: $('sortBy').value
  });
  try {
    const movies = await api(`${API}?${params}`);
    renderMovies(movies);
    updateGenreFilter(movies);
  } catch (e) {
    grid.innerHTML = '';
    emptyBox.hidden = false;
    emptyBox.querySelector('h2').textContent = 'Could not load movies';
    emptyBox.querySelector('p').textContent = e.message + '. Check that the server and MongoDB are running.';
  }
}

function renderMovies(movies) {
  emptyBox.hidden = movies.length > 0;
  if (!movies.length) {
    emptyBox.querySelector('h2').textContent = 'No movies found';
    emptyBox.querySelector('p').textContent = 'Try a different search, or add a new movie to start collecting reviews.';
  }
  grid.innerHTML = movies.map((m) => `
    <button class="ticket" style="--hue:${hueFor(m.genre)}" data-id="${m._id}" aria-label="Open ${esc(m.title)}">
      <div class="main">
        <span class="genre">${esc(m.genre)}</span>
        <h3>${esc(m.title)}</h3>
        <div class="meta">${esc(m.director)} · ${m.year}${m.duration ? ' · ' + m.duration + ' min' : ''}</div>
        <p class="blurb">${esc(m.description || 'No description yet.')}</p>
      </div>
      <div class="stubpart">
        <span class="score">${m.reviewCount ? m.avgRating.toFixed(1) : '–'}</span>
        ${stars(m.avgRating)}
        <span class="count">${m.reviewCount} review${m.reviewCount === 1 ? '' : 's'}</span>
      </div>
    </button>`).join('');
}

// Keep genre dropdown in sync with the genres that exist (only when no genre filter is active)
function updateGenreFilter(movies) {
  const sel = $('genreFilter');
  if (sel.value !== 'all') return;
  const current = new Set([...sel.options].map((o) => o.value));
  movies.map((m) => m.genre).filter((g) => !current.has(g)).forEach((g) => {
    sel.add(new Option(g, g));
    current.add(g);
  });
}

/* ---------- add / edit movie ---------- */
function openMovieForm(movie = null) {
  $('movieForm').reset();
  $('movieError').textContent = '';
  $('movieDialogTitle').textContent = movie ? 'Edit movie' : 'Add movie';
  $('movieId').value = movie ? movie._id : '';
  if (movie) {
    $('title').value = movie.title;
    $('director').value = movie.director;
    $('genre').value = movie.genre;
    $('year').value = movie.year;
    $('duration').value = movie.duration || '';
    $('description').value = movie.description || '';
  }
  movieDialog.showModal();
}

$('movieForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const id = $('movieId').value;
  const body = {
    title: $('title').value.trim(),
    director: $('director').value.trim(),
    genre: $('genre').value,
    year: Number($('year').value),
    duration: $('duration').value ? Number($('duration').value) : undefined,
    description: $('description').value.trim()
  };
  if (!body.title || !body.director || !body.genre || !body.year) {
    $('movieError').textContent = 'Title, director, genre and year are required.';
    return;
  }
  try {
    await api(id ? `${API}/${id}` : API, { method: id ? 'PUT' : 'POST', body });
    movieDialog.close();
    toast(id ? 'Movie updated' : 'Movie added');
    await refresh();
    if (id && openMovieId === id) showDetail(id);
  } catch (err) {
    $('movieError').textContent = err.message;
  }
});

/* ---------- movie detail + reviews ---------- */
async function showDetail(id) {
  try {
    const m = await api(`${API}/${id}`);
    openMovieId = id;
    renderDetail(m);
    if (!detailDialog.open) detailDialog.showModal();
  } catch (e) { toast(e.message, true); }
}

let draftRating = 0;

function renderDetail(m) {
  draftRating = 0;
  $('detailBody').innerHTML = `
    <div class="detail">
      <header>
        <div>
          <h2>${esc(m.title)}</h2>
          <div class="sub">${esc(m.director)} · ${m.year}${m.duration ? ' · ' + m.duration + ' min' : ''} · ${esc(m.genre)}</div>
        </div>
        <button class="btn ghost small" data-close-detail>Close</button>
      </header>

      <div class="big-score">
        <strong>${m.reviewCount ? m.avgRating.toFixed(1) : '–'}</strong>
        <div>${stars(m.avgRating)}<div class="sub">${m.reviewCount} review${m.reviewCount === 1 ? '' : 's'}</div></div>
      </div>

      ${m.description ? `<p class="desc">${esc(m.description)}</p>` : ''}

      <div class="tools">
        <button class="btn ghost small" id="editMovieBtn">Edit movie</button>
        <button class="btn danger small" id="deleteMovieBtn">Delete movie</button>
      </div>

      <div class="panel">
        <h3>Write a review</h3>
        <form id="reviewForm" novalidate>
          <label>Your name<input id="reviewer" maxlength="60" required /></label>
          <div>
            <div class="sub" style="font-size:.88rem;margin-bottom:4px">Rating</div>
            <div class="star-input" id="starInput" role="radiogroup" aria-label="Rating">
              ${[1, 2, 3, 4, 5].map((i) => `<button type="button" data-v="${i}" role="radio" aria-checked="false" aria-label="${i} star${i > 1 ? 's' : ''}">★</button>`).join('')}
            </div>
          </div>
          <label>Review<textarea id="comment" rows="3" maxlength="1000" required></textarea></label>
          <p class="form-error" id="reviewError" role="alert"></p>
          <div class="actions"><button class="btn primary" type="submit">Post review</button></div>
        </form>
      </div>

      <div class="panel">
        <h3>Reviews</h3>
        <div class="reviews">
          ${m.reviews.length ? m.reviews.map((r) => `
            <article class="review">
              <div class="head">
                <span class="who">${esc(r.reviewer)}</span>
                ${stars(r.rating)}
                <time datetime="${r.createdAt}">${fmtDate(r.createdAt)}</time>
                <button class="btn danger small del" data-del-review="${r._id}">Delete</button>
              </div>
              <p>${esc(r.comment)}</p>
            </article>`).join('') : '<p class="no-reviews">No reviews yet. Be the first to write one.</p>'}
        </div>
      </div>
    </div>`;

  // star picker
  const starBtns = [...document.querySelectorAll('#starInput button')];
  starBtns.forEach((b) => b.addEventListener('click', () => {
    draftRating = Number(b.dataset.v);
    starBtns.forEach((x) => {
      const on = Number(x.dataset.v) <= draftRating;
      x.classList.toggle('on', on);
      x.setAttribute('aria-checked', Number(x.dataset.v) === draftRating);
    });
  }));

  $('reviewForm').addEventListener('submit', (e) => submitReview(e, m._id));
  $('editMovieBtn').addEventListener('click', () => openMovieForm(m));
  $('deleteMovieBtn').addEventListener('click', () => deleteMovie(m._id, m.title));
  document.querySelector('[data-close-detail]').addEventListener('click', () => detailDialog.close());
  document.querySelectorAll('[data-del-review]').forEach((b) =>
    b.addEventListener('click', () => deleteReview(m._id, b.dataset.delReview)));
}

async function submitReview(e, movieId) {
  e.preventDefault();
  const reviewer = $('reviewer').value.trim();
  const comment = $('comment').value.trim();
  const err = $('reviewError');
  if (!reviewer || !comment || !draftRating) {
    err.textContent = 'Add your name, pick a star rating and write a comment.';
    return;
  }
  try {
    const updated = await api(`${API}/${movieId}/reviews`, { method: 'POST', body: { reviewer, rating: draftRating, comment } });
    renderDetail(updated);
    toast('Review posted');
    refresh();
  } catch (ex) { err.textContent = ex.message; }
}

async function deleteReview(movieId, reviewId) {
  if (!confirm('Delete this review?')) return;
  try {
    const updated = await api(`${API}/${movieId}/reviews/${reviewId}`, { method: 'DELETE' });
    renderDetail(updated);
    toast('Review deleted');
    refresh();
  } catch (ex) { toast(ex.message, true); }
}

async function deleteMovie(id, title) {
  if (!confirm(`Delete "${title}" and all its reviews?`)) return;
  try {
    await api(`${API}/${id}`, { method: 'DELETE' });
    detailDialog.close();
    toast('Movie deleted');
    refresh();
  } catch (ex) { toast(ex.message, true); }
}

/* ---------- wiring ---------- */
function refresh() { return Promise.all([loadMovies(), loadStats()]); }

grid.addEventListener('click', (e) => {
  const card = e.target.closest('.ticket');
  if (card) showDetail(card.dataset.id);
});
$('addMovieBtn').addEventListener('click', () => openMovieForm());
document.querySelectorAll('[data-close]').forEach((b) => b.addEventListener('click', () => movieDialog.close()));
$('genreFilter').addEventListener('change', loadMovies);
$('sortBy').addEventListener('change', loadMovies);
$('search').addEventListener('input', () => {   // debounce typing
  clearTimeout(searchTimer);
  searchTimer = setTimeout(loadMovies, 250);
});
// click outside a dialog closes it
[movieDialog, detailDialog].forEach((d) =>
  d.addEventListener('click', (e) => { if (e.target === d) d.close(); }));

refresh();
