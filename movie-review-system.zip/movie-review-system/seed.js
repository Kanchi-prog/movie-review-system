// Run with: npm run seed   (clears the movies collection and adds sample data)
require('dotenv').config();
const mongoose = require('mongoose');
const Movie = require('./models/Movie');

const data = [
  { title: 'Inception', director: 'Christopher Nolan', genre: 'Sci-Fi', year: 2010, duration: 148,
    description: 'A thief who steals secrets through dreams is offered a chance to have his past erased.',
    reviews: [
      { reviewer: 'Aarav', rating: 5, comment: 'Layered, clever and the score is unforgettable.' },
      { reviewer: 'Meera', rating: 4, comment: 'Confusing at first, rewarding on a second watch.' } ] },
  { title: 'Dangal', director: 'Nitesh Tiwari', genre: 'Drama', year: 2016, duration: 161,
    description: 'A former wrestler trains his daughters to become world-class champions.',
    reviews: [ { reviewer: 'Rohan', rating: 5, comment: 'Emotional and inspiring from start to finish.' } ] },
  { title: 'The Dark Knight', director: 'Christopher Nolan', genre: 'Action', year: 2008, duration: 152,
    description: 'Batman faces the Joker, a criminal mastermind who pushes Gotham into chaos.',
    reviews: [
      { reviewer: 'Sana', rating: 5, comment: "Ledger's Joker carries the whole film." },
      { reviewer: 'Kabir', rating: 4, comment: 'Gripping, though a little long.' } ] },
  { title: 'Spirited Away', director: 'Hayao Miyazaki', genre: 'Animation', year: 2001, duration: 125,
    description: 'A young girl wanders into a world of spirits and must work to free her parents.',
    reviews: [ { reviewer: 'Isha', rating: 5, comment: 'Pure imagination. Every frame is beautiful.' } ] },
  { title: 'Andhadhun', director: 'Sriram Raghavan', genre: 'Thriller', year: 2018, duration: 139,
    description: 'A blind pianist gets entangled in a murder, or is he really blind?',
    reviews: [ { reviewer: 'Dev', rating: 4, comment: 'Twisty, funny and tense in equal measure.' } ] },
  { title: 'Superbad', director: 'Greg Mottola', genre: 'Comedy', year: 2007, duration: 113,
    description: 'Two high-school friends try to buy alcohol for a party before graduation.', reviews: [] }
];

(async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/movie_review_db');
    await Movie.deleteMany({});
    await Movie.insertMany(data);
    console.log(`Seeded ${data.length} movies`);
  } catch (e) { console.error(e.message); }
  finally { await mongoose.disconnect(); }
})();
