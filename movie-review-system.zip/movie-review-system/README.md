# Reelnotes – Movie Review Management System

A full-stack web app to manage movies and their reviews.

**Stack:** HTML · CSS · JavaScript (front-end) · Node.js + Express (API) · MongoDB + Mongoose (database)

## Features
- Add, edit and delete movies
- Post and delete reviews (name, 1–5 star rating, comment)
- Automatic average rating and review count per movie
- Search by title/director, filter by genre, sort by rating / reviews / year / title
- Dashboard totals (movies, reviews, overall average)
- Input validation on both client and server, XSS-safe rendering

## Setup
1. Install [Node.js](https://nodejs.org) (v18+) and [MongoDB Community](https://www.mongodb.com/try/download/community) (or use a free MongoDB Atlas cluster).
2. In this folder run:
   ```bash
   npm install
   cp .env.example .env      # Windows: copy .env.example .env
   npm run seed              # optional: adds sample movies
   npm start
   ```
3. Open http://localhost:3000

For MongoDB Atlas, put your connection string in `.env` as `MONGO_URI`.

## Project structure
```
movie-review-system/
├── server.js            # Express app + MongoDB connection
├── seed.js              # Sample data loader
├── models/Movie.js      # Mongoose schema (reviews embedded in movie)
├── routes/movies.js     # REST API
└── public/
    ├── index.html       # UI
    ├── style.css        # Styling
    └── script.js        # Front-end logic (fetch API)
```

## REST API
| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/movies?search=&genre=&sort=` | List movies (filter / sort) |
| GET | `/api/movies/stats` | Totals and overall average |
| GET | `/api/movies/:id` | One movie with reviews |
| POST | `/api/movies` | Create movie |
| PUT | `/api/movies/:id` | Update movie |
| DELETE | `/api/movies/:id` | Delete movie |
| POST | `/api/movies/:id/reviews` | Add review |
| DELETE | `/api/movies/:id/reviews/:reviewId` | Delete review |

## Database design
One collection, `movies`. Reviews are embedded sub-documents, so a movie and its reviews load in a single query.

```js
{
  title, director, genre, year, duration, description,
  reviews: [ { reviewer, rating, comment, createdAt } ],
  createdAt, updatedAt
}
```

## Ideas to extend
User login (JWT), poster image upload, review likes, pagination, admin role.
