const mongoose = require('mongoose');

// Each review is embedded inside its movie document
const reviewSchema = new mongoose.Schema(
  {
    reviewer: { type: String, required: [true, 'Reviewer name is required'], trim: true, maxlength: 60 },
    rating:   { type: Number, required: [true, 'Rating is required'], min: 1, max: 5 },
    comment:  { type: String, required: [true, 'Comment is required'], trim: true, maxlength: 1000 }
  },
  { timestamps: true }
);

const movieSchema = new mongoose.Schema(
  {
    title:       { type: String, required: [true, 'Title is required'], trim: true, maxlength: 120 },
    director:    { type: String, required: [true, 'Director is required'], trim: true, maxlength: 80 },
    genre:       { type: String, required: [true, 'Genre is required'], trim: true },
    year:        { type: Number, required: [true, 'Release year is required'], min: 1888, max: 2100 },
    duration:    { type: Number, min: 1, max: 600 },           // minutes
    description: { type: String, trim: true, maxlength: 1500 },
    reviews:     [reviewSchema]
  },
  { timestamps: true }
);

// Virtuals: average rating + review count (included in JSON output)
movieSchema.virtual('avgRating').get(function () {
  if (!this.reviews.length) return 0;
  const sum = this.reviews.reduce((t, r) => t + r.rating, 0);
  return Math.round((sum / this.reviews.length) * 10) / 10;
});
movieSchema.virtual('reviewCount').get(function () { return this.reviews.length; });
movieSchema.set('toJSON', { virtuals: true });
movieSchema.set('toObject', { virtuals: true });

module.exports = mongoose.model('Movie', movieSchema);
